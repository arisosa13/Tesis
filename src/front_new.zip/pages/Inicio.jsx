import { useNavigate } from "react-router-dom";

function Inicio() {
  const navigate = useNavigate();

  return (
    <main className="container py-4">
      <section className="hero-panel mb-4">
        <div className="hero-panel-content">
          <p className="hero-badge">StockIt! / Sistema de Gestión</p>

          <h1>StockIt!</h1>

          <p className="hero-text">
            La forma más inteligente de stockear tu negocio.
          </p>

          <div className="d-flex gap-2 flex-wrap mt-3">
            <span className="badge bg-primary px-3 py-2">Pedidos</span>
            <span className="badge bg-success px-3 py-2">Stock</span>
            <span className="badge bg-warning text-dark px-3 py-2">
              Productos
            </span>
            <span className="badge bg-info text-dark px-3 py-2">Clientes</span>
          </div>
        </div>
      </section>

      <section className="row g-4">
        <div className="col-md-6 col-xl-3">
          <div className="dashboard-card h-100">
            <h3>🛒 Pedidos</h3>
            <p>
              Crear pedidos, agregar productos, confirmar operaciones y consultar
              el historial.
            </p>
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => navigate("/pedidos")}
            >
              Ir a Pedidos
            </button>
          </div>
        </div>

        <div className="col-md-6 col-xl-3">
          <div className="dashboard-card h-100">
            <h3>👥 Clientes</h3>
            <p>
              Registrar clientes, modificar sus datos y buscar información de
              contacto rápidamente.
            </p>
            <button
              type="button"
              className="btn btn-success"
              onClick={() => navigate("/clientes")}
            >
              Ir a Clientes
            </button>
          </div>
        </div>

        <div className="col-md-6 col-xl-3">
          <div className="dashboard-card h-100">
            <h3>📦 Productos</h3>
            <p>
              Gestionar productos, precios, stock disponible, categorías e
              imágenes.
            </p>
            <button
              type="button"
              className="btn btn-warning text-dark"
              onClick={() => navigate("/productos")}
            >
              Ir a Productos
            </button>
          </div>
        </div>

        <div className="col-md-6 col-xl-3">
          <div className="dashboard-card h-100">
            <h3>🚚 Proveedores</h3>
            <p>
              Mantener actualizado el registro de proveedores y sus datos
              comerciales.
            </p>
            <button
              type="button"
              className="btn btn-info text-dark"
              onClick={() => navigate("/proveedores")}
            >
              Ir a Proveedores
            </button>
          </div>
        </div>

        <div className="col-md-6 col-xl-3">
          <div className="dashboard-card h-100">
            <h3>📊 Movimientos de stock</h3>
            <p>
              Registrar ingresos, ajustes, roturas, vencimientos y movimientos
              de inventario.
            </p>
            <button
              type="button"
              className="btn btn-dark"
              onClick={() => navigate("/movimientos-stock")}
            >
              Ir a Stock
            </button>
          </div>
        </div>
      </section>
    </main>
  );
}

export default Inicio;